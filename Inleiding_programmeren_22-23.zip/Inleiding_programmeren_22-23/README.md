# Inleiding_programmeren_22-23

Hoe het spel werkt werkt:

1. vul je naam in en klik op start
2. klik op de banaan om een level omhoog te gaan en te evalueren
3. klik op de barrel om een level omlaag te gaan en te evalueren
